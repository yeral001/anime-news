$(document).ready(function() {
  
    $("#miBoton").click(function() {
        alert("Obteniendo la noticia de anime...");


        $.ajax({
            url: "https://api.jikan.moe/v4/anime/1",
            method: "GET",
            success: function(data) {
              
                $("#datos").html("<h2>" + data.data.title + "</h2><p>" + data.data.synopsis + "</p>");
            },
            error: function() {
                alert("Ocurrió un error al cargar la noticia.");
            }
        });
    });
});






